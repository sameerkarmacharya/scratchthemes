<?php
$servername = "localhsot";
$username = "root";
$password = "root";
$db = "class";

$con = new mysqli($servername, $username, $password, $db);
if ($con->connect_error) {
	echo "Database Error";
} else {
	echo "Database:Success";
}

?>