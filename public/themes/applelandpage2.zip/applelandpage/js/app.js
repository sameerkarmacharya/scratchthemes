$(function(){
	$('.pro-radio input[type="radio"]').click(function(){
		switch($(this).val())
		{
			case 'iPhone 6':
				$('.ipad-feat').removeClass('zoom-in');
				$('.iphone-feat').addClass('zoom-in');
				$('#submit-btn').val('Send My iPhone 6');
			break;
			case 'iPad 2 Air':
				$('.iphone-feat').removeClass('zoom-in');
				$('.ipad-feat').addClass('zoom-in');
				$('#submit-btn').val('Send My ipad 2');
			break;
		}
	});
});