<?php 
include 'db-connect.php';


$id= $_GET['id'];

$delete= "DELETE FROM student_record WHERE id = $id";
mysql_query($delete) or die(mysql_error());
header("Location:show.php");


 ?>